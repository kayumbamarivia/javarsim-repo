package com.me.security.doit.utils;

import com.me.security.doit.models.User;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

public record Teacher(String name, String surname, String email)  {}


