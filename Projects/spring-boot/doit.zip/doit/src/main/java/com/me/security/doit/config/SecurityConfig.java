package com.me.security.doit.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.me.security.doit.filters.JwtAuthFilter;
import com.me.security.doit.services.impl.UserDetailsServiceImpl;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

/**
 * Main security configuration class for the application.
 * Configures authentication, authorization, and security filters.
 * 
 * <p>This class enables web security, configures CSRF protection, session management,
 * and defines security filter chains.</p>
 *
 *Author Fred
 * @version 1.0
 * @see Configuration
 * @see EnableWebSecurity
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    /**
     * Service for loading user details.
     */
    private final UserDetailsServiceImpl user;
    
    /**
     * Filter for JWT authentication.
     */
    private final JwtAuthFilter jwtAuthFilter;
    
    /**
     * Constructs a new SecurityConfig with required dependencies.
     * 
     * @param user the user details service implementation
     * @param jwtAuthFilter the JWT authentication filter
     */
    public SecurityConfig(UserDetailsServiceImpl user, JwtAuthFilter jwtAuthFilter) {
        this.user = user;
        this.jwtAuthFilter = jwtAuthFilter;
    }

    private final String[] WHITE_LIST = {
            "/api/v1/users/auth/**",
            "/actuator/metrics",
            "/actuator/health",
            "/actuator/metrics/**",
            "/v2/api-docs",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui/**",
            "/webjars/**",
            "/swagger-ui.html"
    };
    
    /**
     * Configures the security filter chain.
     * 
     * @param http the HttpSecurity to configure
     * @return the configured SecurityFilterChain
     * @throws Exception if an error occurs during configuration
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(
                    WHITE_LIST
                ).permitAll()
                .requestMatchers("/api/v1/vehicles/create-vehicle/{sellerId}/**", "/api/v1/users/users").hasAuthority("SELLER")
                .requestMatchers("/api/v1/vehicles/get-all/**","/api/v1/vehicles/get/{id}/**", "/api/v1/vehicles/buy-vehicle/{buyerId}/{vehicleId}").hasAnyAuthority("SELLER", "BUYER")
                .anyRequest().authenticated()
            )
            .userDetailsService(user)
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class)
            .build();          
    }
    
    /**
     * Creates an AuthenticationManager bean.
     * 
     * @param conf the AuthenticationConfiguration
     * @return the AuthenticationManager
     * @throws Exception if an error occurs during creation
     */
    @Bean
    public AuthenticationManager authManager(AuthenticationConfiguration conf) throws Exception {
        return conf.getAuthenticationManager();
    }
    
    /**
     * Creates a PasswordEncoder bean for password hashing.
     * 
     * @return the PasswordEncoder implementation (BCrypt)
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:5173"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        config.setExposedHeaders(List.of("Authorization", "Access-Control-Allow-Origin"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}