package com.me.security.doit.models;

public enum Role {
    BUYER,
    SELLER,
}
