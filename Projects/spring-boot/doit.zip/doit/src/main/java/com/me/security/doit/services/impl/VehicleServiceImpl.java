package com.me.security.doit.services.impl;

import com.me.security.doit.dtos.VehicleRequest;
import com.me.security.doit.models.User;
import com.me.security.doit.models.Vehicle;
import com.me.security.doit.repositories.UserRepo;
import com.me.security.doit.repositories.VehicleRepo;
import com.me.security.doit.services.VehicleService;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class VehicleServiceImpl implements VehicleService {
    private final VehicleRepo vrepo;
    private final UserRepo userrepo;

    public VehicleServiceImpl(VehicleRepo vrepo, UserRepo userrepo) {
        this.vrepo = vrepo;
        this.userrepo = userrepo;
    }

    public Vehicle registerVehicle(VehicleRequest vehicleRequest, Long sellerId) {
        Optional<User> u = userrepo.findById(sellerId);
        Vehicle vehicle = new Vehicle();
        vehicle.setTitle(vehicleRequest.title());
        vehicle.setSellerId(u.get().getId());
        vehicle.setPrice(vehicleRequest.price());
        return vrepo.save(vehicle);
    }
    @Override
    public List<Vehicle> getAllVehicles() { return vrepo.findAll();
    }
    public Vehicle getVehicleById(Long id) {
        return vrepo.findById(id).orElse(null);
    }
}
