package com.me.security.doit.services;

import com.me.security.doit.dtos.VehicleRequest;
import com.me.security.doit.models.Vehicle;

import java.util.List;

public interface VehicleService {
    Vehicle registerVehicle (VehicleRequest vehicleRequest, Long sellerId);
    List<Vehicle> getAllVehicles();
}
