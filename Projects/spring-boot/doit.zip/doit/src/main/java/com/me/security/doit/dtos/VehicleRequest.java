package com.me.security.doit.dtos;

import jakarta.validation.constraints.*;

/**
 * Data Transfer Object for vehicle creation/update requests.
 * Contains validation constraints matching the Vehicle entity fields.
 */
public record VehicleRequest(
        String title,
        Double price
) {

}
