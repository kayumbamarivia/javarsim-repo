package com.me.security.doit.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Represents a vehicle entity in the system.
 * This class maps to the "vehicles" table in the database.
 *
 * <p>The vehicle includes basic information and an image stored as a byte array.</p>
 *
 * @author Gisa
 * @version 1.0
 * @since 2024
 */
@Entity
@Table(name = "vehicle")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Vehicle {
    /**
     * The unique identifier for the vehicle.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long vehicleId;
    private Long sellerId;
    private Long buyerId = null;
    /**
     * The title/name of the vehicle listing.
     */
    @Column(nullable = false)
    private String title;

    /**
     * The price of the vehicle.
     */
    @Column(nullable = false)
    private double price;
}