package com.me.security.doit.controllers;

import com.me.security.doit.dtos.VehicleRequest;
import com.me.security.doit.models.Vehicle;
import com.me.security.doit.repositories.VehicleRepo;
import com.me.security.doit.services.impl.VehicleServiceImpl;

import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controller for vehicle-related operations.
 * Handles adding and retrieving vehicles.
 *
 * @author Fred
 * @version 1.0
 */
@RestController
@RequestMapping("/api/v1/vehicles")
public class VehicleController {

    /**
     * Service for vehicle operations.
     */
    private final VehicleServiceImpl vehicleService;
    private final VehicleRepo vehicleRepo;

    /**
     * Constructs a new VehicleController with required service.
     *
     * @param vehicleService the vehicle service implementation
     */
    public VehicleController(VehicleServiceImpl vehicleService, VehicleRepo vehicleRepo) {
        this.vehicleService = vehicleService;
        this.vehicleRepo = vehicleRepo;
    }

    /**
     * Adds a new vehicle.
     *
     * @param vehicle the vehicle to add
     * @return ResponseEntity containing the saved vehicle
     */
    @PostMapping("/create-vehicle/{sellerId}")
    public ResponseEntity<Vehicle> addVehicle(@RequestBody VehicleRequest vehicle, @PathVariable Long sellerId) {
        Vehicle savedVehicle = vehicleService.registerVehicle(vehicle, sellerId);
        return new ResponseEntity<>(savedVehicle, HttpStatus.CREATED);
    }

    /**
     * Retrieves all vehicles.
     *
     * @return list of all vehicles
     */
    @GetMapping("/get-all")
    public ResponseEntity<List<Vehicle>> getAllVehicles() {
        List<Vehicle> vehicles = vehicleService.getAllVehicles();
        return new ResponseEntity<>(vehicles, HttpStatus.OK);
    }

    /**
     * Retrieves a vehicle by ID.
     *
     * @param id the ID of the vehicle
     * @return the vehicle with the given ID
     */
    @GetMapping("/get/{id}")
    public ResponseEntity<Vehicle> getVehicleById(@PathVariable Long id) {
        Vehicle vehicle = vehicleService.getVehicleById(id);
        return ResponseEntity.ok(vehicle);
    }

    @PutMapping("/buy-vehicle/{buyerId}/{vehicleId}")
    public ResponseEntity<Vehicle> buyVehicle(@PathVariable Long buyerId, @PathVariable Long vehicleId) {
        Vehicle v = vehicleRepo.findById(vehicleId).get();
        v.setSellerId(null);
        v.setBuyerId(buyerId);
        return ResponseEntity.ok(vehicleRepo.save(v));
    }
}
