import { useState, useEffect } from 'react';
import { FaSearch, FaBars, FaTimes, FaUser, FaSun, FaMoon, FaSignOutAlt } from 'react-icons/fa';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { useTheme } from '../context/ThemeContext';
import { signOut } from '../redux/user/userSlice';
import toast from 'react-hot-toast';

export default function Header() {
  const { currentUser } = useSelector((state) => state.user);
  const [searchTerm, setSearchTerm] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { isDarkMode, toggleTheme } = useTheme();
  const dispatch = useDispatch();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (searchTerm.trim() !== '') {
      let url = `/search?searchTerm=${encodeURIComponent(searchTerm)}`;
      if (currentUser && currentUser.role === 'SELLER') {
        url += `&userId=${currentUser.id}`;
      }
      navigate(url);
    }
  };

  const handleLogout = async () => {
    try {
      dispatch(signOut());
      toast.success('Logged out successfully!');
      navigate('/sign-in');
    } catch (error) {
      toast.error('Error logging out');
    }
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <header className='bg-white dark:bg-dark-100 shadow-md sticky top-0 z-50 transition-colors duration-200'>
      <div className='max-w-6xl mx-auto p-4'>
        <div className='flex justify-between items-center'>
          <Link to='/home' className='flex items-center space-x-2'>
            <h1 className='font-bold text-xl flex flex-wrap'>
              <span className='text-indigo-600 dark:text-indigo-400'>Drive</span>
              <span className='text-gray-800 dark:text-gray-200'>Deal</span>
            </h1>
          </Link>

          {/* Search Bar */}
          <form
            onSubmit={handleSubmit}
            className='hidden md:flex items-center bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2 flex-1 max-w-md mx-4'
          >
            <input
              type='text'
              placeholder='Search vehicles...'
              className='bg-transparent focus:outline-none w-full text-gray-700 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400'
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search vehicles"
            />
            <button 
              type="submit"
              className='text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors'
              aria-label="Search"
            >
              <FaSearch />
            </button>
          </form>

          {/* Desktop Navigation */}
          <nav className='hidden md:flex items-center space-x-6'>
            <Link 
              to='/home'
              className={`text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors ${
                isActive('/home') ? 'text-indigo-600 dark:text-indigo-400 font-medium' : ''
              }`}
            >
              Home
            </Link>
            <Link 
              to='/about'
              className={`text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors ${
                isActive('/about') ? 'text-indigo-600 dark:text-indigo-400 font-medium' : ''
              }`}
            >
              About
            </Link>
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
              aria-label="Toggle theme"
            >
              {isDarkMode ? (
                <FaSun className="text-yellow-500" />
              ) : (
                <FaMoon className="text-gray-700" />
              )}
            </button>
            {currentUser ? (
              <div className='flex items-center space-x-4'>
                <Link 
                  to='/profile'
                  className='flex items-center space-x-2 text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors'
                >
                  {currentUser.avatar ? (
                    <img
                      src={currentUser.avatar}
                      alt="Profile"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <div className='w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center'>
                      <FaUser className='text-indigo-600 dark:text-indigo-400' />
                    </div>
                  )}
                  <span className='hidden lg:inline'>{currentUser.username}</span>
                </Link>
                <button
                  onClick={handleLogout}
                  className='flex items-center text-gray-700 dark:text-gray-200 hover:text-red-600 dark:hover:text-red-400 transition-colors'
                >
                  <FaSignOutAlt className='w-5 h-5 mr-2' />
                  Logout
                </button>
              </div>
            ) : (
              <Link 
                to='/sign-in'
                className='bg-indigo-600 dark:bg-indigo-500 text-white px-4 py-2 rounded-full hover:bg-indigo-700 dark:hover:bg-indigo-600 transition-colors'
              >
                Sign In
              </Link>
            )}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className='md:hidden text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors'
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle mobile menu"
          >
            {isMobileMenuOpen ? <FaTimes size={24} /> : <FaBars size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className='md:hidden mt-4 space-y-4'>
            <form
              onSubmit={handleSubmit}
              className='flex items-center bg-gray-100 dark:bg-gray-700 rounded-full px-4 py-2'
            >
              <input
                type='text'
                placeholder='Search vehicles...'
                className='bg-transparent focus:outline-none w-full text-gray-700 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400'
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                aria-label="Search vehicles"
              />
              <button 
                type="submit"
                className='text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors'
                aria-label="Search"
              >
                <FaSearch />
              </button>
            </form>
            <nav className='flex flex-col space-y-4'>
              <Link 
                to='/home'
                className={`text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors ${
                  isActive('/home') ? 'text-indigo-600 dark:text-indigo-400 font-medium' : ''
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </Link>
              <Link 
                to='/about'
                className={`text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors ${
                  isActive('/about') ? 'text-indigo-600 dark:text-indigo-400 font-medium' : ''
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About
              </Link>
              <button
                onClick={toggleTheme}
                className="flex items-center space-x-2 text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
                aria-label="Toggle theme"
              >
                {isDarkMode ? (
                  <>
                    <FaSun className="text-yellow-500" />
                    <span>Light Mode</span>
                  </>
                ) : (
                  <>
                    <FaMoon className="text-gray-700" />
                    <span>Dark Mode</span>
                  </>
                )}
              </button>
              {currentUser ? (
                <Link 
                  to='/profile'
                  className='flex items-center space-x-2 text-gray-700 dark:text-gray-200 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors'
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {currentUser.avatar ? (
                    <img
                      src={currentUser.avatar}
                      alt="Profile"
                      className="w-8 h-8 rounded-full object-cover"
                    />
                  ) : (
                    <div className='w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900 flex items-center justify-center'>
                      <FaUser className='text-indigo-600 dark:text-indigo-400' />
                    </div>
                  )}
                  <span>{currentUser.username}</span>
                </Link>
              ) : (
                <Link 
                  to='/sign-in'
                  className='bg-indigo-600 dark:bg-indigo-500 text-white px-4 py-2 rounded-full hover:bg-indigo-700 dark:hover:bg-indigo-600 transition-colors text-center'
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Sign In
                </Link>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
