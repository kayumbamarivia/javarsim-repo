import { useTheme } from '../context/ThemeContext';

const ThemePreview = () => {
  const { isDarkMode } = useTheme();

  return (
    <div className="fixed bottom-4 right-4 bg-white dark:bg-dark-100 rounded-lg shadow-lg p-4 w-64 animate-slide-in">
      <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-100 mb-4">
        Theme Preview
      </h3>
      <div className="space-y-4">
        {/* Text Colors */}
        <div>
          <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Text Colors</h4>
          <div className="space-y-2">
            <p className="text-gray-900 dark:text-gray-100">Primary Text</p>
            <p className="text-gray-600 dark:text-gray-400">Secondary Text</p>
            <p className="text-primary-600 dark:text-primary-400">Accent Text</p>
          </div>
        </div>

        {/* Background Colors */}
        <div>
          <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Background Colors</h4>
          <div className="grid grid-cols-3 gap-2">
            <div className="h-8 bg-white dark:bg-dark-100 rounded border dark:border-gray-700"></div>
            <div className="h-8 bg-gray-100 dark:bg-dark-200 rounded"></div>
            <div className="h-8 bg-primary-100 dark:bg-primary-900/50 rounded"></div>
          </div>
        </div>

        {/* Interactive Elements */}
        <div>
          <h4 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Interactive Elements</h4>
          <div className="space-y-2">
            <button className="w-full bg-primary-600 dark:bg-primary-500 text-white px-4 py-2 rounded-lg hover:bg-primary-700 dark:hover:bg-primary-600 transition-colors">
              Button
            </button>
            <input
              type="text"
              placeholder="Input field"
              className="w-full px-3 py-2 rounded-lg border dark:border-gray-700 bg-white dark:bg-dark-100 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary-500"
            />
          </div>
        </div>

        {/* Current Theme */}
        <div className="pt-2 border-t dark:border-gray-700">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Current Theme: <span className="font-medium text-primary-600 dark:text-primary-400">{isDarkMode ? 'Dark' : 'Light'}</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default ThemePreview; 