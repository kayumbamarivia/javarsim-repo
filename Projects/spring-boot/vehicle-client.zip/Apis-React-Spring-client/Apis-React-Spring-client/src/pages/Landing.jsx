import { Link } from 'react-router-dom';

export default function Landing() {
  return (
    <div>
      <div className='flex flex-col gap-6 p-28 px-3 max-w-6xl mx-auto'>
        <h1 className='text-slate-700 font-bold text-3xl lg:text-6xl'>
          Connect with <span className='text-slate-500'>trusted</span>
          <br />
          sellers and buyers effortlessly
        </h1>
        <div className='text-gray-400 text-xs sm:text-sm'>
          Our platform bridges the gap between sellers and buyers, creating
          <br />
          seamless transactions and valuable business relationships.
        </div>
        <div className="flex gap-4">
          <Link
            to={'/sign-in'}
            className='text-xs sm:text-sm bg-blue-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-blue-700 transition'
          >
            Start Selling
          </Link>
          <Link
            to={'/sign-in'}
            className='text-xs sm:text-sm bg-green-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-green-700 transition'
          >
            Start Buying
          </Link>
        </div>
      </div>
    </div>
  );
}