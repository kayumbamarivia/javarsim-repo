import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { FaCar, FaSort, FaFilter, FaPlus } from 'react-icons/fa';
import toast from 'react-hot-toast';

export default function Index() {
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sortBy, setSortBy] = useState('price');
  const [sortOrder, setSortOrder] = useState('asc');
  const [filterPrice, setFilterPrice] = useState('');
  const { currentUser } = useSelector((state) => state.user);
  const role = currentUser?.role;

  useEffect(() => {
    Load();
  }, [role]);

  async function Load() {
    const loadingToast = toast.loading('Loading vehicles...');
    try {
      setLoading(true);
      setError(null);
      const token = sessionStorage.getItem('token');
      const response = await axios.get("http://localhost:8080/api/v1/vehicles/get-all", {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      setVehicles(response.data.flat());
      toast.success('Vehicles loaded successfully!', {
        id: loadingToast,
      });
    } catch (error) {
      console.error('Error loading vehicles:', error);
      setError('Failed to load vehicles. Please try again later.');
      toast.error('Failed to load vehicles. Please try again later.', {
        id: loadingToast,
      });
    } finally {
      setLoading(false);
    }
  }

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
    toast.success(`Sorted by ${field} ${sortOrder === 'asc' ? 'ascending' : 'descending'}`);
  };

  const handleFilterChange = (value) => {
    setFilterPrice(value);
    if (value) {
      toast.success(`Filtering vehicles under $${value}`);
    } else {
      toast.success('Cleared price filter');
    }
  };

  const filteredAndSortedVehicles = vehicles
    .filter(vehicle => {
      if (!filterPrice) return true;
      return vehicle.price <= parseInt(filterPrice);
    })
    .sort((a, b) => {
      const multiplier = sortOrder === 'asc' ? 1 : -1;
      if (sortBy === 'price') {
        return (a.price - b.price) * multiplier;
      }
      return a[sortBy].localeCompare(b[sortBy]) * multiplier;
    });

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 animate-pulse">
              <div className="h-48 bg-gray-200 dark:bg-gray-700 rounded-lg mb-4"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
              <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 dark:bg-red-900/50 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-200 px-4 py-3 rounded relative" role="alert">
          <strong className="font-bold">Error!</strong>
          <span className="block sm:inline"> {error}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-semibold text-gray-800 dark:text-gray-100">Available Vehicles</h1>
        {role === 'SELLER' && (
          <Link
            to="/new"
            className="bg-indigo-600 dark:bg-indigo-500 text-white px-4 py-2 rounded-full hover:bg-indigo-700 dark:hover:bg-indigo-600 transition-colors flex items-center space-x-2"
            onClick={() => toast.success('Navigating to add new vehicle')}
          >
            <FaPlus />
            <span>Add Vehicle</span>
          </Link>
        )}
      </div>

      {/* Filters and Sort */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex items-center space-x-2">
            <FaFilter className="text-gray-500 dark:text-gray-400" />
            <input
              type="number"
              placeholder="Max Price"
              className="border dark:border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-gray-200 placeholder-gray-500 dark:placeholder-gray-400"
              value={filterPrice}
              onChange={(e) => handleFilterChange(e.target.value)}
            />
          </div>
          <div className="flex items-center space-x-2">
            <FaSort className="text-gray-500 dark:text-gray-400" />
            <select
              className="border dark:border-gray-600 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-gray-200"
              value={sortBy}
              onChange={(e) => handleSort(e.target.value)}
            >
              <option value="price">Price</option>
              <option value="title">Title</option>
            </select>
            <button
              onClick={() => {
                setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                toast.success(`Sorting ${sortOrder === 'asc' ? 'descending' : 'ascending'}`);
              }}
              className="text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400"
            >
              {sortOrder === 'asc' ? '↑' : '↓'}
            </button>
          </div>
        </div>
      </div>

      {/* Vehicle Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAndSortedVehicles.map((vehicle) => (
          <div 
            key={vehicle.id} 
            className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
            onClick={() => toast.success(`Selected vehicle: ${vehicle.title}`)}
          >
            <div className="h-48 bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center">
              <FaCar className="text-4xl text-indigo-600 dark:text-indigo-400" />
            </div>
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100 mb-2">{vehicle.title}</h2>
              <div className="flex justify-between items-center mb-4">
                <span className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">${vehicle.price}</span>
                <span className="text-sm text-gray-500 dark:text-gray-400">ID: {vehicle.id}</span>
              </div>
              <div className="border-t dark:border-gray-700 pt-4">
                <div className="flex justify-between text-sm text-gray-600 dark:text-gray-300">
                  <span>Seller ID: {vehicle.sellerId}</span>
                  <span>Buyer ID: {vehicle.buyerId || 'Not sold'}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredAndSortedVehicles.length === 0 && (
        <div className="text-center py-12">
          <FaCar className="text-4xl text-gray-400 dark:text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-medium text-gray-600 dark:text-gray-400">No vehicles found</h3>
          <p className="text-gray-500 dark:text-gray-500 mt-2">Try adjusting your filters or add a new vehicle</p>
        </div>
      )}
    </div>
  );
}
