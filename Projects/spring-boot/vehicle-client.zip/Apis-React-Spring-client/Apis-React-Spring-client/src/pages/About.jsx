export default function About() {
  return (
    <div className='py-20 px-4 max-w-6xl mx-auto'>
      <h1 className='text-3xl font-bold mb-4 text-slate-800'>DriveDeal</h1>
      <p className='mb-4 text-slate-700'>Drive Deal is a premier automotive marketplace that connects buyers and sellers, making the car buying and selling process seamless and efficient. Our platform specializes in creating meaningful connections between automotive enthusiasts and dealers, ensuring a smooth and trustworthy transaction experience.</p>
      <p className='mb-4 text-slate-700'>
        Our mission is to revolutionize the automotive marketplace by providing a secure, user-friendly platform where buyers can find their dream vehicles and sellers can reach qualified buyers. Whether you're looking to buy your next car or sell your current vehicle, Drive Deal is your trusted partner in the automotive journey.
      </p>
      <p className='mb-4 text-slate-700'>With years of experience in the automotive industry, we understand the importance of trust and transparency in vehicle transactions. We're committed to providing exceptional service, detailed vehicle information, and a secure platform for all our users. At Drive Deal, we believe that buying and selling vehicles should be an exciting and stress-free experience, and we're dedicated to making that a reality for every user on our platform.</p>
    </div>
  )
}